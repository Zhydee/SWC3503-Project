<?php
// Set the timezone to Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "Failed admin login attempt for username: $username with password: $password at $timestamp\n";
    
    // Log to a file
    file_put_contents('failed_admin_logins.log', $logEntry, FILE_APPEND);

   
    echo 'Logged';
} else {
    echo 'Invalid request';
}
