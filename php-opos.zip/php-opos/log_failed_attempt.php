<?php
// Set the timezone to Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "Failed login attempt for email: $email at $timestamp\n";
    
    // Log to a file
    file_put_contents('failed_logins.log', $logEntry, FILE_APPEND);

   

    echo 'Logged';
} else {
    echo 'Invalid request';
}
